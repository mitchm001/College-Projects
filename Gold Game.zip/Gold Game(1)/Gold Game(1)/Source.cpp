#include <iostream>
#include <cstdlib>
#include <ctime>
#include <time.h>
#include <stdlib.h>
using namespace std;

const int ROWS = 8;
const int COLS = 8;
//const int NUM_GUESS = 5;
const int gold = 5;
void printGameBoard(char board[ROWS][COLS]);

int main()
{
	char again = 'Y';
	const int ROWS = 8;
	const int COLS = 8;
	char board[COLS][ROWS];

	
		for (int row = 0; row < ROWS; row++)
		{
			for (int col = 0; col < COLS; col++)
			{
				board[row][col] = 0;			//board is filled with ???
			}
		}

		cout << "    1   2   3   4   5   6   7   8" << endl;
		cout << "  +---+---+---+---+---+---+---+---+" << endl;
		for (int row = 0; row < ROWS; row++)
		{
			cout << row + 1 << "|";
			for (int col = 0; col < COLS; col++)
			{
				cout << board[row][col] << " ? ";
			}
			cout << endl;
			cout << "  +---+---+---+---+---+---+---+---+" << endl;
		}

		cout << "\nFind the Gold!" << endl;
		cout << "\nThere are 5 pieces of Gold..." << endl;
		cout << "\nand one Bomb..." << endl;
		cout << "\nYou have 5 guesses," << endl;
		cout << "\nGood Luck!!" << endl;

		printGameBoard(board);
		system("pause");
		return 0;
	
}


void printGameBoard(char board[ROWS][COLS])
		{
			int row, col;

			for (row = 0; row < ROWS; row++)		//clearing the array so the whole board is blank
				for (col = 0; col < COLS; col++)
					board[row][col];

			srand((unsigned int)time(NULL));						//seeding random number generator

			int randomRow, randomCol;

			for (int gHide = 0; gHide < gold; gHide++)
			{
				randomRow = rand() % ROWS;		//hiding the gold
				randomCol = rand() % COLS;
				board[randomRow][randomCol] = 'X';
			}

			for (int bHide = 0; bHide < 1; bHide++)
			{
				randomRow = rand() % ROWS;		//hiding the bomb
				randomCol = rand() % COLS;
				board[randomRow][randomCol] = 'Z';
			}

			int rowGuess, colGuess;
			int guessLeft = 5;
			static int score = 0;
			char again;

			do
			{
				while (guessLeft > 0)												//checking guesses..... begin while loop
				{
					cout << "Which column across? 1 - 8 " << ": ";
					cin >> colGuess;
					cout << "Which row down? 1 - 8" << ": ";
					cin >> rowGuess;

					if (board[rowGuess][colGuess] == 'X')
					{
						cout << "Congratulations! You found gold!!" << endl;
						cout << colGuess << ", " << rowGuess << " )" << endl;
						cout << "Score: " << score + 1 << endl;
						guessLeft--;
						cout << "Guesses left: " << guessLeft << endl;

						board[rowGuess][colGuess] = 'G';						//marks the gold on the board if found
					}

					else if (board[rowGuess][colGuess] == 'Z')
					{
						cout << "Oh no! You hit the bomb! :'( " << endl;
						cout << colGuess << ", " << rowGuess << " )" << endl;
						guessLeft = 0;
						cout << "Game Over..." << endl;

						board[rowGuess][colGuess] = 'B';									//marks bomb if found
					}

					else if (board[rowGuess][colGuess] != 'X', 'Z')
					{
						cout << "Oops!  Nothing here!" << endl;										//no gold
						guessLeft--;
						cout << "Guesses left: " << guessLeft << endl;
					}
				}
				cout << "" << endl;				//spacing
				cout << "" << endl;				//spacing

				cout << "Would you like to play again? (y/n)" << endl;
				cin >> again;
			} while (again == 'Y' || again == 'y');
		}
